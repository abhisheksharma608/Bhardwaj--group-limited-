<?php
session_start();
include("db.php");

if (!isset($_SESSION["user_id"])) {
    echo "<script>alert('You are not logged in!'); window.location.href='login.html';</script>";
    exit();
}

$user_id = $_SESSION["user_id"];
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $phone = $_POST["phone"];
    $address = $_POST["address"];
    $dob = $_POST["dob"];
    $stmt = $conn->prepare("UPDATE users SET phone=?, address=?, dob=? WHERE id=?");
    $stmt->bind_param("sssi", $phone, $address, $dob, $user_id);
    $stmt->execute();
    echo "<script>alert('Profile updated successfully.');</script>";
}

$stmt = $conn->prepare("SELECT * FROM users WHERE id=?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result()->fetch_assoc();
?>
<!DOCTYPE html>
<html>
<head>
    <title>Edit Profile</title>
</head>
<body>
    <h2>Edit Your Profile</h2>
    <form method="post">
        Phone: <input type="text" name="phone" value="<?php echo $result['phone']; ?>"><br><br>
        Address: <input type="text" name="address" value="<?php echo $result['address']; ?>"><br><br>
        Date of Birth: <input type="date" name="dob" value="<?php echo $result['dob']; ?>"><br><br>
        <button type="submit">Update Profile</button>
    </form>
</body>
</html>
