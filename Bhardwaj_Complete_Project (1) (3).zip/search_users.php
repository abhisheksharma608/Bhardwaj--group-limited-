<?php
session_start();
if (!isset($_SESSION["admin_logged_in"])) {
    header("Location: admin_login.php");
    exit();
}
include("db.php");

$search = "";
$results = [];

if (isset($_GET["query"])) {
    $search = $_GET["query"];
    $stmt = $conn->prepare("SELECT * FROM users WHERE name LIKE ? OR username LIKE ?");
    $likeSearch = "%" . $search . "%";
    $stmt->bind_param("ss", $likeSearch, $likeSearch);
    $stmt->execute();
    $results = $stmt->get_result();
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Search Users - Admin</title>
</head>
<body>
    <h2>Search Users</h2>
    <form method="get">
        <input type="text" name="query" placeholder="Search by name or username" value="<?php echo htmlspecialchars($search); ?>">
        <button type="submit">Search</button>
    </form>
    <br>
    <table border="1">
        <tr><th>Name</th><th>Username</th><th>Email</th><th>Phone</th></tr>
        <?php if (!empty($results)): ?>
            <?php while ($row = $results->fetch_assoc()): ?>
                <tr>
                    <td><?php echo htmlspecialchars($row["name"]); ?></td>
                    <td><?php echo htmlspecialchars($row["username"]); ?></td>
                    <td><?php echo htmlspecialchars($row["email"]); ?></td>
                    <td><?php echo htmlspecialchars($row["phone"]); ?></td>
                </tr>
            <?php endwhile; ?>
        <?php endif; ?>
    </table>
</body>
</html>
