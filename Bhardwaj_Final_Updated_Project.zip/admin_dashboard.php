<?php
include 'db.php';
session_start();
if (!isset($_SESSION["admin_username"])) {
    echo "<script>alert('Access Denied'); window.location.href='admin_login.php';</script>";
    exit();
}
echo "<a href='admin_logout.php'>Logout</a><br>";
$result = $conn->query("SELECT * FROM users");
echo "<h2>All Registered Users:</h2>";
echo "<table border='1'><tr><th>ID</th><th>Name</th><th>Email</th><th>Phone</th><th>Address</th><th>DOB</th><th>Actions</th></tr>";
while ($row = $result->fetch_assoc()) {
    echo "<tr>
    <td>{$row['id']}</td>
    <td>{$row['name']}</td>
    <td>{$row['email']}</td>
    <td>{$row['phone']}</td>
    <td>{$row['address']}</td>
    <td>{$row['dob']}</td>
    <td>
        <a href='edit_user.php?id={$row['id']}'>Edit</a> |
        <a href='delete_user.php?id={$row['id']}' onclick='return confirm("Are you sure?")'>Delete</a>
    </td>
    </tr>";
}
echo "</table>";
?>
