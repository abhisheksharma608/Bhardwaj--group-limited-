<?php
session_start();
if (!isset($_SESSION['user_id'])) {
  header("Location: login.html");
  exit();
}
?>

<!DOCTYPE html>
<html>
<head>
  <title>User Profile</title>
  <style>
    body { font-family: Arial; background: #f2f2f2; padding: 2rem; }
    .profile-box {
      max-width: 600px; margin: auto; background: white; padding: 2rem;
      border-radius: 12px; text-align: center; box-shadow: 0 0 12px #ccc;
    }
    img { width: 120px; height: 120px; border-radius: 50%; object-fit: cover; }
    p { font-size: 1.1rem; margin: 0.5rem 0; }
  </style>
</head>
<body>

<div class="profile-box">
  <img src="uploads/<?php echo $_SESSION['profile_pic']; ?>" alt="Profile Picture">
  <h2><?php echo $_SESSION['user_name']; ?></h2>
  <p><strong>Email:</strong> <?php echo $_SESSION['user_email']; ?></p>
  <p><strong>Phone:</strong> <?php echo $_SESSION['user_phone']; ?></p>
  <p><strong>Date of Birth:</strong> <?php echo $_SESSION['user_dob']; ?></p>
  <p><strong>Address:</strong> <?php echo $_SESSION['user_address']; ?></p>
  <p><strong>Registered On:</strong> <?php echo $_SESSION['created_at']; ?></p>
  <a href="logout.php">Logout</a>
</div>

</body>
</html>
