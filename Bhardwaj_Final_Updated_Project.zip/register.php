<?php
$host = "localhost";
$user = "root";
$pass = "";
$db = "bhardwaj_db";

$conn = new mysqli($host, $user, $pass, $db);
if ($conn->connect_error) die("Connection failed");

$name = $_POST['name'];
$email = $_POST['email'];
$password = password_hash($_POST['password'], PASSWORD_DEFAULT);
$phone = $_POST['phone'];
$dob = $_POST['dob'];
$address = $_POST['address'];

$profile_pic = $_FILES['profile_pic']['name'];
$tmp_pic = $_FILES['profile_pic']['tmp_name'];
$target = "uploads/" . basename($profile_pic);
move_uploaded_file($tmp_pic, $target);

$sql = "INSERT INTO users (name, email, password, phone, dob, address, profile_pic) VALUES (?, ?, ?, ?, ?, ?, ?)";
$stmt = $conn->prepare($sql);
$stmt->bind_param("sssssss", $name, $email, $password, $phone, $dob, $address, $profile_pic);

if ($stmt->execute()) {
  echo "Registration successful!";
} else {
  echo "Registration failed!";
}
?>