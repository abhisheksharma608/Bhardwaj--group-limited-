<?php
session_start();
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST["username"];
    $password = $_POST["password"];

    if ($username === "Abhishek Bhardwaj" && $password === "Abhi@123") {
        $_SESSION["admin"] = $username;
        header("Location: admin_dashboard.php");
        exit();
    } else {
        echo "<p class='error' style='text-align:center;color:red;'>Invalid credentials. Try again.</p>";
    }
}
?>
