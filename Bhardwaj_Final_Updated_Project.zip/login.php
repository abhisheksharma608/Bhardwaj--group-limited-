<?php
session_start();
$conn = new mysqli("localhost", "root", "", "bhardwaj_db");

$email = $_POST['email'];
$password = $_POST['password'];

$sql = "SELECT * FROM users WHERE email=?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $email);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 1) {
  $user = $result->fetch_assoc();
  if (password_verify($password, $user['password'])) {
    $_SESSION['user_id'] = $user['id'];
    $_SESSION['user_name'] = $user['name'];
    $_SESSION['user_email'] = $user['email'];
    $_SESSION['user_phone'] = $user['phone'];
    $_SESSION['user_dob'] = $user['dob'];
    $_SESSION['user_address'] = $user['address'];
    $_SESSION['profile_pic'] = $user['profile_pic'];
    $_SESSION['created_at'] = $user['created_at'];
    echo "success";
  } else {
    echo "Invalid password";
  }
} else {
  echo "User not found";
}
?>