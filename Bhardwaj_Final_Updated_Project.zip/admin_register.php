<?php
include 'db.php';
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $owner_pass = $_POST["owner_password"];
    if ($owner_pass !== "Bhardwajcompany@419") {
        echo "<script>alert('Invalid owner password');</script>";
    } else {
        $name = $_POST["name"];
        $username = $_POST["username"];
        $password = password_hash($_POST["password"], PASSWORD_DEFAULT);

        $stmt = $conn->prepare("INSERT INTO admins (name, username, password) VALUES (?, ?, ?)");
        $stmt->bind_param("sss", $name, $username, $password);
        if ($stmt->execute()) {
            echo "Admin registered successfully.";
        } else {
            echo "Error: " . $stmt->error;
        }
        $stmt->close();
    }
}
?>
<form method="post">
  <input type="password" name="owner_password" placeholder="Owner Password" required><br>
  <input type="text" name="name" placeholder="Full Name" required><br>
  <input type="text" name="username" placeholder="Username" required><br>
  <input type="password" name="password" placeholder="Password" required><br>
  <button type="submit">Register Admin</button>
</form>
